﻿window.PlayAudio = (elementName) => {
    document.getElementById(elementName).play();
}